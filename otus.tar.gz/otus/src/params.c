#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include "ctx.h"

extern struct adc_context *ctx;
extern int period_msec;
extern int duration_sec;

static int run_set(const char *val, const struct kernel_param *kp);
static int period_set(const char *val, const struct kernel_param *kp);
static int duration_set(const char *val, const struct kernel_param *kp);
static int result_get(char *buffer, const struct kernel_param *kp);
static int stats_get(char *buffer, const struct kernel_param *kp);



static int run_test(void)
{
	if (ctx->running)
		return ADC_BUSY;

	/* Открываем файл для записи данных */
	//ctx->data_file = filp_open(DATA_FILE_PATH, O_WRONLY | O_CREAT | O_TRUNC, 0644);
	ctx->data_file = filp_open(DATA_FILE_PATH, O_WRONLY | O_CREAT | O_TRUNC| O_APPEND, 0644);
	if (IS_ERR(ctx->data_file)) {
		pr_err("Cannot create data file %s\n", DATA_FILE_PATH);
		return PTR_ERR(ctx->data_file);
	}

	/* Сбрасываем счетчик сэмплов */
	ctx->sample_count = 0;
	
	/* Записываем время начала */
	ctx->start_time = ktime_get();
	
	/* Инициализируем workqueue */
	INIT_WORK(&ctx->work, adc_read_work);

	/* Запускаем таймер */
	timer_init(period_msec);
	
	pr_info("ADC sampling started for %d seconds with period %d ms\n", duration_sec, period_msec);

	return ADC_OK;
}

static int stop_test(void)
{
	if (ctx->running) {
		hrtimer_cancel(&ctx->timer);
		cancel_work_sync(&ctx->work);
		ctx->running = false;
		
		/* Закрываем файл с данными */
		if (ctx->data_file && !IS_ERR(ctx->data_file)) {
			filp_close(ctx->data_file, NULL);
			ctx->data_file = NULL;
		}
		
		pr_info("ADC sampling stopped. Total samples: %lu\n", ctx->sample_count);
		return ADC_OK;
	} else {
		return ADC_INVALID;
	}
}

static const struct kernel_param_ops run_ops = {
	.set = run_set,
};

static int run_set(const char *val, const struct kernel_param *kp)
{
	unsigned int cmd;
	int ret;

	ret = kstrtouint(val, 0, &cmd);
	if (ret)
		return ADC_INVALID;

	if (cmd != 0 && cmd != 1)
		return ADC_INVALID;
		
	if (cmd)
		ret = run_test();
	else
		ret = stop_test();

	return ret;
}

static const struct kernel_param_ops period_ops = {
	.set = period_set,
};

static int period_set(const char *val, const struct kernel_param *kp)
{
	unsigned int cmd;
	int ret;

	ret = kstrtouint(val, 0, &cmd);
	if (ret)
		return ADC_INVALID;
	if (cmd <= 0 || cmd > 1000){
		printk(KERN_ERR "Period of ADC Sampling must be in [1 sec..1000 msec]\n");
		return ADC_INVALID;
		}
		
	period_msec = cmd;
	pr_info("New period value: %d msec\n", cmd);

	return ADC_OK;
}

static const struct kernel_param_ops duration_ops = {
	.set = duration_set,
};

static int duration_set(const char *val, const struct kernel_param *kp)
{
	unsigned int cmd;
	int ret;

	ret = kstrtouint(val, 0, &cmd);
	if (ret)
		return ADC_INVALID;
	if (cmd <= 1 || cmd > 60){
		printk(KERN_ERR "Duration of ADC Sampling must be in [1 sec..60 sec]\n");
		return ADC_INVALID;
		}
		
	duration_sec = cmd;
	pr_info("New duration value: %d sec\n", cmd);

	return ADC_OK;
}


static const struct kernel_param_ops result_ops = {
	.get = result_get,
};

static const struct kernel_param_ops stats_ops = {
	.get = stats_get,
};


/* result - вывод результата */
static int result_get(char *buffer, const struct kernel_param *kp)
{
	
	return snprintf(buffer, PAGE_SIZE,
			"Test is %s\n",
			ctx->running == 0 ? "ready to run" : "processing...");
}

/* stats - статистика */
static int stats_get(char *buffer, const struct kernel_param *kp)
{
	return snprintf(
		buffer, PAGE_SIZE,
		"Duration=%u sec, Samping count=%lu\n",
		duration_sec, ctx->sample_count);
}


module_param_cb(run, &run_ops, NULL, 0200);
MODULE_PARM_DESC(run, "1/0 Start/Stop ADC Sampling");
module_param_cb(set_period, &period_ops, NULL, 0200);
MODULE_PARM_DESC(set_period, "Period [1 msec..1000 msec] of ADC Sampling");
module_param_cb(set_duration, &duration_ops, NULL, 0200);
MODULE_PARM_DESC(set_duration, "Duration [1 sec..60 sec] of ADC Sampling");
module_param_cb(result, &result_ops, NULL, 0444);
MODULE_PARM_DESC(result, "Result of ADC Sampling");
module_param_cb(stats, &stats_ops, NULL, 0444);
MODULE_PARM_DESC(stats, "Statistics");
