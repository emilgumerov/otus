#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include "ctx.h"

extern struct adc_context *ctx;
extern int period_msec;

static int run_set(const char *val, const struct kernel_param *kp);
static int interval_set(const char *val, const struct kernel_param *kp);

static int run_test(void)
{
	if (ctx->running)
		return PC_BUSY;

	INIT_WORK(&ctx->work, adc_read_work);

	timer_init(period_msec);

	return PC_OK;
}

static int stop_test(void)
{
	if (ctx->running){
		hrtimer_cancel(&ctx->timer);
		cancel_work_sync(&ctx->work);
		ctx->running = false;
		return PC_OK;
		}
		else
		return PC_INVALID;
}



static const struct kernel_param_ops run_ops = {
	.set = run_set,
};


static int run_set(const char *val, const struct kernel_param *kp)
{
	unsigned int cmd;
	int ret;

	ret = kstrtouint(val, 0, &cmd);
	if (ret)
		return PC_INVALID;

	if (cmd != 0 && cmd != 1)
		return PC_INVALID;
		
	if(cmd)
		ret = run_test();
	else
		ret = stop_test();

	return ret;
}


static const struct kernel_param_ops interval_ops = {
	.set = interval_set,
};


static int interval_set(const char *val, const struct kernel_param *kp)
{
	unsigned int cmd;
	int ret;

	ret = kstrtouint(val, 0, &cmd);
	if (ret)
		return PC_INVALID;
	if (cmd <= 0 || cmd > 1000)
		return PC_INVALID;
		
	period_msec = cmd;
	pr_info("New period value: %d msec\n", cmd);

/*	if (cmd != 0 && cmd != 1)
		return PC_INVALID;
		
	if(cmd)
		ret = run_test();
	else
		ret = stop_test();
*/
	return ret;
}



module_param_cb(run, &run_ops, NULL, 0200);
MODULE_PARM_DESC(run, "1/0 Start/Stop ADC Sampling");
module_param_cb(set_interval, &interval_ops, NULL, 0200);
MODULE_PARM_DESC(set_interval, "Period (msec)of ADC Sampling");

/*module_param_cb(result, &result_ops, NULL, 0444);
module_param_cb(stats, &stats_ops, NULL, 0444);
module_param_cb(consumer_type_change, &consumer_type_ops, NULL, 0200);
module_param_cb(reset, &reset_ops, NULL, 0200);*/

