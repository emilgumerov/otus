#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include "ctx.h"

struct adc_context *ctx;

/* Период выборки (миллисекунды) */
int period_msec = 1;

/* Период буферизации данных (секунды) */
int duration_sec = 2;

int timer_init(int period_msec)
{
	printk(KERN_INFO "Timer started with sampling period %d ms\n",
	       period_msec);
	hrtimer_init(&ctx->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	ctx->timer.function = producer;
	ctx->period = ktime_set(0, period_msec * NSEC_PER_MSEC);

	/* Запускаем таймер */
	hrtimer_start(&ctx->timer, ctx->period, HRTIMER_MODE_REL);
	ctx->running = true;
	return ADC_OK;
}

void timer_exit(void)
{
	if (ctx->running) {
		hrtimer_cancel(&ctx->timer);
		ctx->running = false;
	}
}

static int __init adc_module_init(void)
{
	int ret;

	pr_info("ADC sampling module loading\n");

	/* Выделяем память под структуру */
	ctx = kmalloc(sizeof(struct adc_context), GFP_KERNEL);
	if (!ctx)
		return ADC_NOMEM;

	/* Открываем sysfs файл АЦП для дальнейшего чтения */
	ctx->adc_file = filp_open(ADC_PATH, O_RDONLY, 0);
	if (IS_ERR(ctx->adc_file)) {
		ret = PTR_ERR(ctx->adc_file);
		pr_err("Cannot open %s: %d\n", ADC_PATH, ret);
		kfree(ctx);
		return ret;
	}

	/* Проверяем, что читается */
	ret = read_adc_value(ctx->adc_file);
	if (ret < 0) {
		pr_err("Cannot read ADC: %d\n", ret);
		filp_close(ctx->adc_file, NULL);
		kfree(ctx);
		return ret;
	}
	pr_info("Initial ADC value: %d\n", ret);

	/* начальная инициализация стуктуры */
	ctx->running = false;
	ctx->sample_count = 0;
	ctx->sum = 0;
	ctx->min = 0;
	ctx->max = 0;
	ctx->initialized = false;

	pr_info("ADC module loaded, sampling period %d ms\n", period_msec);
	return ADC_OK;
}

static void __exit adc_module_exit(void)
{
	if (ctx) {
		/* Останавливаем таймер если активен */
		if (ctx->running) {
			hrtimer_cancel(&ctx->timer);
			cancel_work_sync(&ctx->work);
		}

		/* Закрываем файлы */
		if (ctx->data_file && !IS_ERR(ctx->data_file))
			filp_close(ctx->data_file, NULL);

		if (ctx->adc_file && !IS_ERR(ctx->adc_file))
			filp_close(ctx->adc_file, NULL);

		/* освобождаем память */
		kfree(ctx);
	}
	pr_info("ADC sampling module unloaded\n");
}

module_init(adc_module_init);
module_exit(adc_module_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Emil Gumerov");
MODULE_DESCRIPTION("ADC sampling module");
