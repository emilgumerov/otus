#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include "ctx.h"



struct adc_context *ctx;

int period_msec = 20;

int timer_init(int period_msec)
{/*
	ktime_t ktime;
	printk(KERN_INFO "hrtimer_init\n");
	hrtimer_init(&ctx->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	ctx->timer.function = producer; // установка ф-ции обратного вызова
	ktime = ktime_set(0, ctx->interval_us * 1000); //интервал
	hrtimer_start(&ctx->timer, ktime, HRTIMER_MODE_REL);
	printk(KERN_INFO "Timer started with interval %u ns\n",
	       ctx->interval_us * 1000);
	ctx->running = true;
	ctx->tm_inited = true;
	return PC_OK;
	*/
	//struct adc_context *ctx = container_of(timer, struct adc_context, timer);

	/* Инициализация workqueue */
	//INIT_WORK(&ctx->work, adc_read_work);
	/* Инициализация hrtimer (50 Гц = 20 мс) */
	
	printk(KERN_INFO "Timer started with interval %d ms\n",
	       period_msec);
	hrtimer_init(&ctx->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	ctx->timer.function = producer;
	ctx->period = ktime_set(0, period_msec * NSEC_PER_MSEC); /* 20 мс */

	/* Запускаем таймер */
	hrtimer_start(&ctx->timer, ctx->period,
		      HRTIMER_MODE_REL);
	ctx->running = true;
	return 0;
}

void timer_exit(void)
{
	if (ctx->running) {
		hrtimer_cancel(&ctx->timer);
		ctx->running = false;
	}
}

static int __init adc_module_init(void)
{
	int ret;

	pr_info("ADC module loading\n");

	/* Выделяем память */
	ctx = kmalloc(sizeof(struct adc_context), GFP_KERNEL);
	if (!ctx)
		return -ENOMEM;

	/* Открываем sysfs файл АЦП */
	ctx->adc_file = filp_open(ADC_PATH, O_RDONLY, 0);
	if (IS_ERR(ctx->adc_file)) {
		ret = PTR_ERR(ctx->adc_file);
		pr_err("Cannot open %s: %d\n", ADC_PATH, ret);
		kfree(ctx);
		return ret;
	}

	/* Проверяем, что читается */
	ret = read_adc_value(ctx->adc_file);
	if (ret < 0) {
		pr_err("Cannot read ADC: %d\n", ret);
		filp_close(ctx->adc_file, NULL);
		kfree(ctx);
		return ret;
	}
	pr_info("Initial ADC value: %d\n", ret);
	
	ctx->running = false;

	/* Инициализация workqueue */
	//INIT_WORK(&ctx->work, adc_read_work);

	/*
	hrtimer_init(&ctx->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	ctx->timer.function = producer;
	ctx->period = ktime_set(0, 20 * NSEC_PER_MSEC);


	hrtimer_start(&ctx->timer, ctx->period,
		      HRTIMER_MODE_REL);*/
	//timer_init(period_msec);

	pr_info("ADC module loaded, sampling at 50 Hz\n");
	return 0;
}

static void __exit adc_module_exit(void)
{
	if (ctx) {
		/* Останавливаем таймер */
		if(ctx->running){
			hrtimer_cancel(&ctx->timer);
		/* Ждем завершения текущей работы */
			cancel_work_sync(&ctx->work);
		}
		/* Закрываем файл */
		if (ctx->adc_file && !IS_ERR(ctx->adc_file))
			filp_close(ctx->adc_file, NULL);

		kfree(ctx);
	}
	pr_info("ADC module unloaded\n");
}

module_init(adc_module_init);
module_exit(adc_module_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Emil Gumerov");
MODULE_DESCRIPTION("ADC sampling");

/*#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/kthread.h>
#include <linux/delay.h>

static struct task_struct *adc_thread;
static int running = 1;

static int read_adc_value(void)
{
	struct file *file;
	mm_segment_t old_fs;
	char buf[16];
	ssize_t bytes_read;
	loff_t pos = 0;
	int value;

	file = filp_open("/sys/bus/iio/devices/iio:device0/in_voltage0_raw",
			 O_RDONLY, 0);
	if (IS_ERR(file))
		return -1;

	old_fs = get_fs();
	set_fs(KERNEL_DS);
	bytes_read = vfs_read(file, buf, sizeof(buf) - 1, &pos);
	set_fs(old_fs);
	filp_close(file, NULL);

	if (bytes_read <= 0)
		return -1;

	buf[bytes_read] = '\0';
	if (kstrtoint(buf, 10, &value) < 0)
		return -1;

	return value;
}

static int adc_collector(void *data)
{
	int val;

	while (running) {
		val = read_adc_value();
		if (val >= 0) {
			printk(KERN_INFO "ADC: %d\n", val);
		}
		msleep(20); // 50 Гц = 20 мс 
	}
	return 0;
}

static int __init adc_module_init(void)
{
	printk(KERN_INFO "ADC module loading...\n");

	//Проверка доступности АЦП 
	if (read_adc_value() < 0) {
		printk(KERN_ERR "ADC not accessible\n");
		return -ENODEV;
	}

	adc_thread = kthread_run(adc_collector, NULL, "adc_collector");
	if (IS_ERR(adc_thread)) {
		printk(KERN_ERR "Failed to create thread\n");
		return PTR_ERR(adc_thread);
	}

	printk(KERN_INFO "ADC module loaded, sampling at 50 Hz\n");
	return 0;
}

static void __exit adc_module_exit(void)
{
	running = 0;
	if (adc_thread)
		kthread_stop(adc_thread);
	printk(KERN_INFO "ADC module unloaded\n");
}

module_init(adc_module_init);
module_exit(adc_module_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("ADC reading with thread");
*/
