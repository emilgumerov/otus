#ifndef CTX_H
#define CTX_H

#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/slab.h>
#include <linux/workqueue.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/moduleparam.h>
/*
#include <linux/random.h>
#include <linux/slab.h>
#include <linux/moduleparam.h>
#include <linux/kfifo.h>
#include <linux/interrupt.h>
#include <linux/workqueue.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/delay.h>
*/
#define PC_OK 0 /* операция успешна */
#define PC_INVALID -EINVAL /* неверный параметр */
#define PC_NOMEM -ENOMEM /* недостаточно памяти */
#define PC_BUSY -EBUSY /* тест уже выполняется */
#define PC_TIMEOUT -ETIMEDOUT /* тест не завершился вовремя */


#define ADC_PATH "/sys/bus/iio/devices/iio:device0/in_voltage0_raw"

struct adc_context {
	struct hrtimer timer;
	struct work_struct work;
	ktime_t period;
	int last_value;
	struct file *adc_file;
	bool running;
};


enum hrtimer_restart producer(struct hrtimer *timer);
int read_adc_value(struct file *file);
void adc_read_work(struct work_struct *work);
int timer_init(int period_msec);
void timer_exit(void);

/*void work_consumer(struct work_struct *work);
void tasklet_consumer(unsigned long data);
int timer_init(void);
void timer_exit(void);
*/

#endif /* CTX_H */
