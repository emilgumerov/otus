#ifndef CTX_H
#define CTX_H

#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/slab.h>
#include <linux/workqueue.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/moduleparam.h>
#include <linux/kfifo.h>

#define ADC_OK 0
#define ADC_INVALID -EINVAL
#define ADC_NOMEM -ENOMEM
#define ADC_BUSY -EBUSY
#define ADC_TIMEOUT -ETIMEDOUT

#define ADC_PATH "/sys/bus/iio/devices/iio:device0/in_voltage1_raw"
#define DATA_FILE_PATH "/tmp/adc_samples.txt"


struct adc_context {
	struct hrtimer timer;
	struct work_struct work;
	ktime_t period;
	int last_value;
	struct file *adc_file;
	struct file *data_file;
	bool running;
	ktime_t start_time;  /* Время начала сэмплирования */
	unsigned long sample_count;  /* Счетчик сэмплов */
};

enum hrtimer_restart producer(struct hrtimer *timer);
int read_adc_value(struct file *file);
void adc_read_work(struct work_struct *work);
int timer_init(int period_msec);
void timer_exit(void);

#endif /* CTX_H */
