#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include "ctx.h"
#include <linux/time64.h>

extern struct pc_ctx *ctx;
extern int duration_sec;

/* Функция чтения АЦП через sysfs (может спать - безопасно) */
int read_adc_value(struct file *file)
{
	char buf[16];
	mm_segment_t old_fs;
	loff_t pos = 0;
	ssize_t bytes;
	int value;

	if (!file)
		return ADC_INVALID;

	old_fs = get_fs();
	set_fs(KERNEL_DS);

	/* Возвращаемся в начало файла */
	bytes = vfs_llseek(file, 0, SEEK_SET);
	if (bytes < 0) {
		set_fs(old_fs);
		return bytes;
	}

	/* Читаем значение */
	bytes = vfs_read(file, buf, sizeof(buf) - 1, &pos);
	set_fs(old_fs);

	if (bytes < 0)
		return bytes;

	buf[bytes] = '\0';
	if (kstrtoint(buf, 10, &value) < 0)
		return ADC_INVALID;

	return value;
}

/* Сохранение значения в файл */
static int save_adc_value(struct file *file, int value, unsigned long sample_num)
{
	char buf[64];
	mm_segment_t old_fs;
	loff_t pos = 0;
	ssize_t bytes;
	int len;

	if (!file)
		return ADC_INVALID;

	/* Формируем строку: "sample_num: value\n" */
	len = snprintf(buf, sizeof(buf), "%lu: %d\n", sample_num, value);
	if (len <= 0)
		return ADC_INVALID;

	old_fs = get_fs();
	set_fs(KERNEL_DS);

	/* Записываем значение */
	bytes = vfs_write(file, buf, len, &pos);
	set_fs(old_fs);

	if (bytes < 0)
		return bytes;

	return ADC_OK;
}


void adc_read_work(struct work_struct *work)
{
	struct adc_context *ctx = container_of(work, struct adc_context, work);
	ktime_t current_time;
	s64 elapsed_ms;
	int val;

	if (!ctx->running)
		return;

	/* Проверяем, не прошло ли duration_sec секунд */
	current_time = ktime_get();
	elapsed_ms = ktime_ms_delta(current_time, ctx->start_time);
	
	if (elapsed_ms >= duration_sec*1000) {
		/* Время вышло - останавливаем сэмплирование */
		printk(KERN_INFO "ADC sampling completed after %d seconds, %lu samples collected\n", 
		       duration_sec, ctx->sample_count);
		
		if (ctx->running) {
			hrtimer_cancel(&ctx->timer);
			ctx->running = false;
		}
		return;
	}

	/* Читаем значение АЦП */
	val = read_adc_value(ctx->adc_file);
	if (val < 0) {
		printk(KERN_ERR "ADC read error: %d\n", val);
		return;
	}

	ctx->last_value = val;
	ctx->sample_count++;

	/* Сохраняем в файл */
	if (save_adc_value(ctx->data_file, val, ctx->sample_count) < 0) {
		printk(KERN_ERR "Failed to save ADC value to file\n");
	} else {
		printk(KERN_INFO "ADC[%lu]: %d (elapsed: %lld ms)\n", 
		       ctx->sample_count, val, elapsed_ms);
	}
}
