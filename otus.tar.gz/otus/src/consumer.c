#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include "ctx.h"

extern struct pc_ctx *ctx;




/* Функция чтения АЦП через sysfs (может спать - безопасно) */
int read_adc_value(struct file *file)
{
	char buf[16];
	mm_segment_t old_fs;
	loff_t pos = 0;
	ssize_t bytes;
	int value;

	if (!file)
		return -EINVAL;

	old_fs = get_fs();
	set_fs(KERNEL_DS);

	/* Возвращаемся в начало файла */
	bytes = vfs_llseek(file, 0, SEEK_SET);
	if (bytes < 0) {
		set_fs(old_fs);
		return bytes;
	}

	/* Читаем значение */
	bytes = vfs_read(file, buf, sizeof(buf) - 1, &pos);
	set_fs(old_fs);

	if (bytes < 0)
		return bytes;

	buf[bytes] = '\0';
	if (kstrtoint(buf, 10, &value) < 0)
		return -EINVAL;

	return value;
}

/* Работа в контексте процесса - безопасно вызываем vfs_read */
void adc_read_work(struct work_struct *work)
{
	struct adc_context *ctx = container_of(work, struct adc_context, work);
	int val;

	val = read_adc_value(ctx->adc_file);
	if (val < 0) {
		printk(KERN_ERR "ADC read error: %d\n", val);
		return;
	}

	ctx->last_value = val;
	printk(KERN_INFO "ADC: %d\n", val);
}
