#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include "ctx.h"

extern struct adc_context *ctx;

enum hrtimer_restart producer(struct hrtimer *timer)
{
	struct adc_context *ctx =
		container_of(timer, struct adc_context, timer);

	/* передаем выполнение в глобальную очередь работ (workqueue) */
	schedule_work(&ctx->work);

	/* Перезапускаем таймер */
	hrtimer_forward_now(timer, ctx->period);
	return HRTIMER_RESTART;
}
