#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np
import sys

# Чтение данных из файла
filename = '/tmp/adc_samples.txt'  
samples = []
values = []

try:
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#') or line.startswith('==='):
                continue
            
            # Парсим строку формата "X: Y"
            if ':' in line:
                parts = line.split(':')
                try:
                    sample = int(parts[0].strip())
                    value = int(parts[1].strip())
                    samples.append(sample)
                    values.append(value)
                except ValueError:
                    print(f"Пропущена строка: {line}")
                    continue
                    
except FileNotFoundError:
    print(f"Ошибка: Файл {filename} не найден")
    sys.exit(1)

if not values:
    print("Нет данных для построения графика")
    sys.exit(1)

# Преобразуем в numpy массивы (опционально)
time = np.array(samples)
values = np.array(values)

# Построение графика
plt.figure(figsize=(10, 6))
plt.plot(time, values, marker='.', linestyle='-', label='ADC Value', linewidth=1, markersize=2)

plt.title('ADC Samples over Time')
plt.xlabel('Sample Number')
plt.ylabel('ADC Value')
plt.grid(True, alpha=0.3)
plt.legend()

# Добавляем статистику на график
stats_text = f'Всего: {len(values)} | Мин: {np.min(values)} | Макс: {np.max(values)} | Сред: {np.mean(values):.1f}'
plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes,
         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.7))

# Сохранить в файл
output_file = 'adc_plot_python.png'
plt.savefig(output_file, dpi=150, bbox_inches='tight')
print(f"График сохранен в: {output_file}")

# Вывод статистики в консоль
print(f"\n=== Статистика ===")
print(f"Количество сэмплов: {len(values)}")
print(f"Минимальное значение: {np.min(values)}")
print(f"Максимальное значение: {np.max(values)}")
print(f"Среднее значение: {np.mean(values):.2f}")
print(f"Стандартное отклонение: {np.std(values):.2f}")

# Показать на экране
plt.show()
